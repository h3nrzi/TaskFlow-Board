import { test, expect } from './test';
import { type Task } from '../../apps/web/src/workspace/types';
import { seedWorkspace, navigate } from './workspace';

const task = (id: string, title: string, changes: Partial<Task>): Task => ({
  id, title, description: '', projectId: '', status: 'todo', priority: 'medium',
  createdAt: '2026-10-20', updatedAt: '2026-10-20', ...changes,
});
async function seedDiscovery(page: Parameters<typeof seedWorkspace>[0]) {
  await seedWorkspace(page, { tasks: [
    task('alpha', 'Alpha capture', { projectId: 'source', description: 'Needle in context', priority: 'high', dueDate: '2026-10-21' }),
    task('beta', 'Beta capture', { projectId: 'source', priority: 'urgent', dueDate: '2026-10-25', updatedAt: '2026-10-23' }),
    task('gamma', 'Gamma review', { projectId: 'destination', status: 'in-progress', dueDate: '2026-10-25', updatedAt: '2026-10-22' }),
    task('delta', 'Delta standalone', { priority: 'low', updatedAt: '2026-10-21' }),
    task('epsilon', 'Epsilon done', { status: 'done', priority: 'urgent', dueDate: '', updatedAt: '2026-10-23' }),
  ] });
}

test('search identifies title, description and project matches with combined filters and recovery', async ({ page }) => {
  await seedDiscovery(page);
  await page.goto('/tasks');
  const titles = page.getByTestId(/^button-open-task-/);
  await page.getByTestId('input-task-search').fill('ALPHA');
  await expect(titles).toHaveText(['Alpha capture']);
  await page.getByTestId('input-task-search').fill('needle');
  await expect(titles).toHaveText(['Alpha capture']);
  await page.getByTestId('input-task-search').fill('SOURCE PROJECT');
  await expect(titles).toHaveText(['Beta capture', 'Alpha capture']);
  await page.getByTestId('filter-task-status').selectOption('todo');
  await page.getByTestId('filter-task-priority').selectOption('urgent');
  await page.getByTestId('filter-task-project').selectOption('source');
  await expect(titles).toHaveText(['Beta capture']);
  await page.getByTestId('filter-task-project').selectOption('');
  await expect(titles).toHaveCount(0);
  await expect(page.getByText('No tasks match those filters', { exact: true })).toBeVisible();
  await page.getByTestId('input-task-search').fill('');
  await page.getByTestId('filter-task-status').selectOption('all');
  await page.getByTestId('filter-task-priority').selectOption('all');
  await expect(titles).toHaveText(['Epsilon done', 'Delta standalone']);
  await page.getByTestId('filter-task-project').selectOption('all');
  await expect(titles).toHaveCount(5);
  await expect(page.getByTestId('task-row-alpha')).toContainText('Source project');
  await expect(page.getByTestId('task-row-gamma')).toContainText('Destination project');
});

test('sorts order every result, keep undated work last and respect meaningful recency groups', async ({ page }) => {
  await seedDiscovery(page);
  await page.goto('/tasks');
  const titles = page.getByTestId(/^button-open-task-/);
  await page.getByTestId('sort-tasks').selectOption('priority');
  await expect(titles).toHaveText(['Beta capture', 'Epsilon done', 'Alpha capture', 'Gamma review', 'Delta standalone']);
  await page.getByTestId('sort-tasks').selectOption('due');
  await expect(titles).toHaveText(['Alpha capture', 'Beta capture', 'Gamma review', 'Delta standalone', 'Epsilon done']);
  await page.getByTestId('sort-tasks').selectOption('updated');
  // Date-only recency cannot order edits within the same day. Check the tied group as a set.
  await expect(titles).toHaveCount(5);
  expect((await titles.allTextContents()).slice(0, 2).sort()).toEqual(['Beta capture', 'Epsilon done']);
  await expect(titles.nth(2)).toHaveText('Gamma review');
  await expect(titles.nth(3)).toHaveText('Delta standalone');
  await expect(titles.nth(4)).toHaveText('Alpha capture');
});

test('in-app navigation retains shell search and resets page filters and sorting on remount', async ({ page }) => {
  await seedDiscovery(page);
  await page.goto('/tasks');
  await page.getByTestId('input-task-search').fill('capture');
  await page.getByTestId('filter-task-status').selectOption('todo');
  await page.getByTestId('filter-task-priority').selectOption('urgent');
  await page.getByTestId('filter-task-project').selectOption('source');
  await page.getByTestId('sort-tasks').selectOption('due');
  await expect(page.getByTestId(/^button-open-task-/)).toHaveText(['Beta capture']);
  await navigate(page, 'projects');
  await navigate(page, 'tasks');
  await expect(page.getByTestId('input-task-search')).toHaveValue('capture');
  for (const id of ['filter-task-status', 'filter-task-priority', 'filter-task-project']) await expect(page.getByTestId(id)).toHaveValue('all');
  await expect(page.getByTestId('sort-tasks')).toHaveValue('updated');
  await expect(page.getByTestId(/^button-open-task-/)).toHaveText(['Beta capture', 'Alpha capture']);
  await page.reload();
  await expect(page.getByTestId('input-task-search')).toHaveValue('');
  await expect(page.getByTestId(/^task-row-/)).toHaveCount(5);
});
